// ============================================
var fs = require('fs');
var url = require('url');
var http = require('http');
var querystring = require('querystring');
var db = []; // database
// ============================================
// function gui yeu cau(response) tu phia server hoac nhan yeu cau(require) cau client gui len
function requestHandler(request, response){
    // Gia su dia chi nhan duoc http://192.168.1.7:8000/update?temp=30&humd=40
    var urlData  = url.parse(request.url);
    var pathname = urlData.pathname; // update?
    var query    = urlData.query;  // temp=30.5&humd=40
    var queryData = querystring.parse(query); // tempData.temp = 30.5, queryData.humd = 40
    //  =======================================
    if(pathname == '/update'){
        var newData = {
            temp : queryData.temp,
            humd : queryData.humd,
            time : new Date()
        };
        db.push(newData);
        console.log(newData);
        response.end();
// ===========================================
    }else if(pathname == '/get'){
        response.writeHead(200,{
            'Content-Type' : 'application/json'
        });
        response.end(JSON.stringify(db));
        db = [];
    }else{
        fs.readFile('./index.html', function(error, content){
            response.writeHead(200,{
                'Content-Type': 'text/html'
            });
            response.end(content);
        });
    }
    // ========================================
}
var server = http.createServer(requestHandler);
server.listen(8000);
console.log('Server listening on port 8000');
